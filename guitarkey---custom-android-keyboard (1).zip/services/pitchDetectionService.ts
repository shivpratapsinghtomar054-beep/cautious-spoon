
import { InstrumentType } from '../types';

class PitchDetectionService {
  private audioCtx: AudioContext | null = null;
  private analyser: AnalyserNode | null = null;
  private microphone: MediaStreamAudioSourceNode | null = null;
  private dataArray: Uint8Array | null = null;
  private animationId: number | null = null;

  public async start(onNoteDetected: (note: string | null) => void, sensitivity: number) {
    try {
      if (!this.audioCtx) {
        this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
      }

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      this.microphone = this.audioCtx.createMediaStreamSource(stream);
      this.analyser = this.audioCtx.createAnalyser();
      this.analyser.fftSize = 2048;
      this.microphone.connect(this.analyser);

      const bufferLength = this.analyser.frequencyBinCount;
      this.dataArray = new Uint8Array(bufferLength);

      const detect = () => {
        if (!this.analyser || !this.dataArray) return;
        this.analyser.getByteFrequencyData(this.dataArray);

        let maxVal = -Infinity;
        let maxIndex = -1;

        // Sensitivity threshold
        const threshold = 255 - (sensitivity * 2.5);

        for (let i = 0; i < this.dataArray.length; i++) {
          if (this.dataArray[i] > maxVal && this.dataArray[i] > threshold) {
            maxVal = this.dataArray[i];
            maxIndex = i;
          }
        }

        if (maxIndex !== -1) {
          const frequency = maxIndex * (this.audioCtx!.sampleRate / this.analyser.fftSize);
          const detectedNote = this.frequencyToKey(frequency);
          onNoteDetected(detectedNote);
        } else {
          onNoteDetected(null);
        }

        this.animationId = requestAnimationFrame(detect);
      };

      detect();
    } catch (err) {
      console.error('Microphone access denied or error:', err);
    }
  }

  public stop() {
    if (this.animationId) cancelAnimationFrame(this.animationId);
    if (this.microphone) this.microphone.disconnect();
    this.analyser = null;
  }

  private frequencyToKey(freq: number): string | null {
    // Map frequency back to our keyboard A-Z (110Hz to 466Hz approx)
    const notes = [
      110.00, 116.54, 123.47, 130.81, 138.59, 146.83, 155.56, 164.81, 174.61, 
      185.00, 196.00, 207.65, 220.00, 233.08, 246.94, 261.63, 277.18, 293.66, 
      311.13, 329.63, 349.23, 369.99, 392.00, 415.30, 440.00, 466.16
    ];
    
    let minDiff = Infinity;
    let closestIndex = -1;

    // Check base frequency and octaves
    const searchFreqs = [freq, freq / 2, freq / 4, freq * 2];

    for (const f of searchFreqs) {
      for (let i = 0; i < notes.length; i++) {
        const diff = Math.abs(f - notes[i]);
        if (diff < minDiff && diff < notes[i] * 0.05) { // 5% tolerance
          minDiff = diff;
          closestIndex = i;
        }
      }
    }

    if (closestIndex !== -1) {
      return String.fromCharCode(65 + closestIndex);
    }
    return null;
  }
}

export const pitchDetectionService = new PitchDetectionService();
