
import { Song, SongNote } from '../types';

class SongAnalysisService {
  public async analyzeMP3(file: File, onProgress: (p: number) => void): Promise<Song> {
    const audioCtx = new AudioContext();
    const arrayBuffer = await file.arrayBuffer();
    const audioBuffer = await audioCtx.decodeAudioData(arrayBuffer);
    
    // Offline analysis context
    const offlineCtx = new OfflineAudioContext(
      audioBuffer.numberOfChannels,
      audioBuffer.length,
      audioBuffer.sampleRate
    );

    const source = offlineCtx.createBufferSource();
    source.buffer = audioBuffer;

    const analyser = offlineCtx.createAnalyser();
    analyser.fftSize = 2048;
    source.connect(analyser);
    analyser.connect(offlineCtx.destination);

    source.start(0);

    const notes: SongNote[] = [];
    const step = 0.1; // 100ms analysis steps
    const duration = audioBuffer.duration;
    
    const bufferLength = analyser.frequencyBinCount;
    const dataArray = new Uint8Array(bufferLength);

    // Analysis loop - we manually iterate through the buffer to detect peaks
    // Since we're in a web env, we can't easily "scrub" an offline ctx during rendering,
    // so we use a specialized approach: we'll use a ScriptProcessor or similar to analyze in chunks
    // To keep it simple and performant, we'll perform the FFT manually using a standard library logic if available,
    // but here we will simulate the extraction of peaks from the time-domain data directly or via small slices.
    
    for (let time = 0; time < duration; time += step) {
      // Logic for frequency detection at 'time'
      // For a real production app, we would use an FFT library on the AudioBuffer slices.
      // Here we approximate the extraction.
      const sampleOffset = Math.floor(time * audioBuffer.sampleRate);
      const slice = audioBuffer.getChannelData(0).slice(sampleOffset, sampleOffset + 2048);
      
      const freq = this.detectPitch(slice, audioBuffer.sampleRate);
      const key = this.frequencyToKey(freq);
      
      if (key) {
        // If the same note is already active, extend its duration instead of adding new
        const lastNote = notes[notes.length - 1];
        if (lastNote && lastNote.key === key && (time * 1000 - (lastNote.time + lastNote.duration)) < 150) {
          lastNote.duration = (time * 1000) - lastNote.time + 100;
        } else {
          notes.push({
            key,
            time: time * 1000,
            duration: 100
          });
        }
      }
      
      onProgress(Math.floor((time / duration) * 100));
    }

    return {
      id: btoa(file.name + file.size),
      name: file.name.replace(/\.[^/.]+$/, ""),
      notes,
      duration: duration * 1000
    };
  }

  // Auto-correlation based pitch detection
  private detectPitch(buffer: Float32Array, sampleRate: number): number {
    let SIZE = buffer.length;
    let rms = 0;
    for (let i = 0; i < SIZE; i++) rms += buffer[i] * buffer[i];
    rms = Math.sqrt(rms / SIZE);
    if (rms < 0.01) return 0; // Quiet

    let r1 = 0, r2 = SIZE - 1, thres = 0.2;
    for (let i = 0; i < SIZE / 2; i++) if (Math.abs(buffer[i]) < thres) { r1 = i; break; }
    for (let i = 1; i < SIZE / 2; i++) if (Math.abs(buffer[SIZE - i]) < thres) { r2 = SIZE - i; break; }

    const buf = buffer.slice(r1, r2);
    SIZE = buf.length;

    const c = new Float32Array(SIZE).fill(0);
    for (let i = 0; i < SIZE; i++) {
      for (let j = 0; j < SIZE - i; j++) {
        c[i] = c[i] + buf[j] * buf[j + i];
      }
    }

    let d = 0;
    while (c[d] > c[d + 1]) d++;
    let maxval = -1, maxpos = -1;
    for (let i = d; i < SIZE; i++) {
      if (c[i] > maxval) {
        maxval = c[i];
        maxpos = i;
      }
    }

    let T0 = maxpos;
    return sampleRate / T0;
  }

  private frequencyToKey(freq: number): string | null {
    if (freq < 80 || freq > 1000) return null;
    const notes = [
      110.00, 116.54, 123.47, 130.81, 138.59, 146.83, 155.56, 164.81, 174.61, 
      185.00, 196.00, 207.65, 220.00, 233.08, 246.94, 261.63, 277.18, 293.66, 
      311.13, 329.63, 349.23, 369.99, 392.00, 415.30, 440.00, 466.16
    ];
    
    let minDiff = Infinity;
    let closestIndex = -1;

    for (let i = 0; i < notes.length; i++) {
      const diff = Math.abs(freq - notes[i]);
      if (diff < minDiff && diff < notes[i] * 0.08) {
        minDiff = diff;
        closestIndex = i;
      }
    }

    return closestIndex !== -1 ? String.fromCharCode(65 + closestIndex) : null;
  }
}

export const songAnalysisService = new SongAnalysisService();
