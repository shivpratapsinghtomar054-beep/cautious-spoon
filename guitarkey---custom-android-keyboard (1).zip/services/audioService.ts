
import { InstrumentType } from '../types';

class AudioService {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;

  private init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
      this.masterGain = this.ctx.createGain();
      this.masterGain.connect(this.ctx.destination);
    }
  }

  // Frequency mapping for A-Z keys (starting from A2)
  private getFrequency(key: string, transposition: number = 0): number {
    const notes = [
      110.00, 116.54, 123.47, 130.81, 138.59, 146.83, 155.56, 164.81, 174.61, 
      185.00, 196.00, 207.65, 220.00, 233.08, 246.94, 261.63, 277.18, 293.66, 
      311.13, 329.63, 349.23, 369.99, 392.00, 415.30, 440.00, 466.16
    ];
    const index = key.toUpperCase().charCodeAt(0) - 65;
    let freq = notes[index % notes.length];
    
    // Apply transposition (f2 = f1 * 2^(n/12))
    if (transposition !== 0) {
      freq = freq * Math.pow(2, transposition / 12);
    }
    
    return freq;
  }

  public playNote(key: string, volume: number, type: InstrumentType, transposition: number = 0) {
    this.init();
    if (!this.ctx || !this.masterGain) return;
    if (this.ctx.state === 'suspended') this.ctx.resume();

    let freq = this.getFrequency(key, transposition);
    
    if (type === InstrumentType.SITAR) freq *= 2; 
    if (type === InstrumentType.HARP) freq *= 2;

    this.masterGain.gain.setTargetAtTime(volume / 100, this.ctx.currentTime, 0.01);

    const sampleRate = this.ctx.sampleRate;
    const period = Math.floor(sampleRate / freq);
    const duration = type === InstrumentType.PIANO ? 1.0 : 2.0;
    const buffer = this.ctx.createBuffer(1, sampleRate * duration, sampleRate);
    const data = buffer.getChannelData(0);

    for (let i = 0; i < period; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    let decay = 0.992;
    let alpha = 0.5;

    switch (type) {
      case InstrumentType.ELECTRIC: decay = 0.998; break;
      case InstrumentType.SITAR: decay = 0.996; alpha = 0.1; break;
      case InstrumentType.HARP: decay = 0.994; alpha = 0.8; break;
      case InstrumentType.PIANO: decay = 0.985; alpha = 0.4; break;
    }

    for (let i = period; i < data.length; i++) {
      data[i] = (data[i - period] * (1 - alpha) + data[i - period + 1] * alpha) * decay;
      if (type === InstrumentType.SITAR) {
        data[i] += (Math.random() - 0.5) * 0.01 * Math.exp(-i / 5000);
      }
    }

    const source = this.ctx.createBufferSource();
    source.buffer = buffer;

    if (type === InstrumentType.ELECTRIC) {
      const distortion = this.ctx.createWaveShaper();
      distortion.curve = this.makeDistortionCurve(400);
      source.connect(distortion);
      distortion.connect(this.masterGain);
    } else {
      source.connect(this.masterGain);
    }

    source.start();
  }

  private makeDistortionCurve(amount: number) {
    const k = amount;
    const n_samples = 44100;
    const curve = new Float32Array(n_samples);
    const deg = Math.PI / 180;
    for (let i = 0; i < n_samples; ++i) {
      const x = (i * 2) / n_samples - 1;
      curve[i] = ((3 + k) * x * 20 * deg) / (Math.PI + k * Math.abs(x));
    }
    return curve;
  }
}

export const audioService = new AudioService();
