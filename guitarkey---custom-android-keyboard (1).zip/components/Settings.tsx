
import React from 'react';
import { KeyboardSettings, InstrumentType } from '../types';

interface SettingsProps {
  settings: KeyboardSettings;
  onUpdate: (newSettings: KeyboardSettings) => void;
  onBack: () => void;
}

const Settings: React.FC<SettingsProps> = ({ settings, onUpdate, onBack }) => {
  const instruments = [
    { id: InstrumentType.ACOUSTIC, name: 'Acoustic', icon: 'fa-guitar' },
    { id: InstrumentType.ELECTRIC, name: 'Electric', icon: 'fa-bolt' },
    { id: InstrumentType.SITAR, name: 'Sitar', icon: 'fa-music' },
    { id: InstrumentType.HARP, name: 'Harp', icon: 'fa-lines-leaning' },
    { id: InstrumentType.PIANO, name: 'Piano', icon: 'fa-keyboard' },
  ];

  const colors = [
    { name: 'Cyan', value: '#06b6d4' },
    { name: 'Emerald', value: '#10b981' },
    { name: 'Rose', value: '#f43f5e' },
    { name: 'Amber', value: '#f59e0b' },
    { name: 'Violet', value: '#8b5cf6' },
  ];

  return (
    <div className="p-6 h-full flex flex-col bg-slate-900 animate-in fade-in slide-in-from-right duration-300">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={onBack} className="p-2 hover:bg-slate-800 rounded-full transition-colors">
          <i className="fa-solid fa-arrow-left text-xl"></i>
        </button>
        <h2 className="text-2xl font-bold">Settings</h2>
      </div>

      <div className="space-y-8 flex-1 overflow-y-auto pr-2 pb-8">
        {/* Instrument Selection */}
        <div className="space-y-4">
          <h3 className="font-semibold text-lg">Instrument Mapping</h3>
          <div className="grid grid-cols-2 gap-4">
            {instruments.map((instr) => (
              <button 
                key={instr.id}
                onClick={() => onUpdate({ ...settings, instrumentType: instr.id })}
                className={`p-4 rounded-xl border-2 transition-all flex flex-col items-center gap-2 ${
                  settings.instrumentType === instr.id ? 'border-blue-500 bg-blue-500/10' : 'border-slate-700 bg-slate-800'
                }`}
              >
                <i className={`fa-solid ${instr.icon} text-2xl ${settings.instrumentType === instr.id ? 'text-blue-400' : 'text-slate-400'}`}></i>
                <span className="text-sm font-medium">{instr.name}</span>
              </button>
            ))}
          </div>
        </div>

        {/* Music Mode Deep Settings */}
        <div className="space-y-6 pt-4 border-t border-slate-800">
          <h3 className="font-bold text-xl text-blue-400 flex items-center gap-2">
            <i className="fa-solid fa-wand-magic-sparkles"></i>
            Music Mode Config
          </h3>

          <div className="space-y-4">
            <div className="flex justify-between items-center">
              <h3 className="font-semibold">Pitch Sensitivity</h3>
              <span className="text-blue-400 font-mono">{settings.musicMode.sensitivity}%</span>
            </div>
            <input 
              type="range" 
              min="0" 
              max="100" 
              value={settings.musicMode.sensitivity}
              onChange={(e) => onUpdate({ 
                ...settings, 
                musicMode: { ...settings.musicMode, sensitivity: parseInt(e.target.value) } 
              })}
              className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
            />
            <p className="text-xs text-slate-500 italic">Higher sensitivity detects quieter sounds but may catch more background noise.</p>
          </div>

          <div className="space-y-4">
            <h3 className="font-semibold">Highlight Color</h3>
            <div className="flex flex-wrap gap-3">
              {colors.map(color => (
                <button
                  key={color.value}
                  onClick={() => onUpdate({ 
                    ...settings, 
                    musicMode: { ...settings.musicMode, highlightColor: color.value } 
                  })}
                  style={{ backgroundColor: color.value }}
                  className={`w-10 h-10 rounded-full border-4 transition-transform active:scale-90 ${
                    settings.musicMode.highlightColor === color.value ? 'border-white scale-110' : 'border-transparent'
                  }`}
                  title={color.name}
                />
              ))}
            </div>
          </div>
        </div>

        {/* Standard Volume */}
        <div className="space-y-4 pt-4 border-t border-slate-800">
          <div className="flex justify-between items-center">
            <h3 className="font-semibold">General Volume</h3>
            <span className="text-blue-400 font-mono">{settings.volume}%</span>
          </div>
          <input 
            type="range" 
            min="0" 
            max="100" 
            value={settings.volume}
            onChange={(e) => onUpdate({ ...settings, volume: parseInt(e.target.value) })}
            className="w-full h-2 bg-slate-700 rounded-lg appearance-none cursor-pointer accent-blue-500"
          />
        </div>
      </div>
    </div>
  );
};

export default Settings;
