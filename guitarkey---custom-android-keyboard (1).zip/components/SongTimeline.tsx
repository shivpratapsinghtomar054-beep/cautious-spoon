
import React from 'react';
import { Song, MusicModeSettings } from '../types';

interface SongTimelineProps {
  song: Song;
  currentTime: number;
  settings: MusicModeSettings;
}

const SongTimeline: React.FC<SongTimelineProps> = ({ song, currentTime, settings }) => {
  const windowSize = 3000; // Show 3 seconds ahead
  const pixelsPerMs = 0.2; // Speed of scroll

  const visibleNotes = song.notes.filter(n => 
    n.time >= currentTime - 500 && n.time <= currentTime + windowSize
  );

  return (
    <div className="h-24 bg-slate-800/80 rounded-xl overflow-hidden relative border border-slate-700 shadow-inner mb-4">
      {/* Strike Line */}
      <div className="absolute left-8 top-0 bottom-0 w-[2px] bg-white/50 z-10">
        <div className="absolute -left-1 top-0 w-3 h-3 bg-white rounded-full blur-[2px]"></div>
      </div>

      <div className="absolute top-0 bottom-0 left-8 right-0 overflow-hidden">
        {visibleNotes.map((note, idx) => {
          const left = (note.time - currentTime) * pixelsPerMs;
          const width = note.duration * pixelsPerMs;
          
          return (
            <div
              key={idx}
              className="absolute h-4 rounded-full flex items-center justify-center text-[8px] font-bold text-white shadow-lg overflow-hidden"
              style={{
                left,
                width: Math.max(width, 15),
                top: `${(note.key.charCodeAt(0) - 65) * 3}px`, // Vertical separation by note
                backgroundColor: settings.highlightColor,
                boxShadow: `0 0 8px ${settings.highlightColor}`,
                opacity: left < 0 ? 0.3 : 1
              }}
            >
              {note.key}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default SongTimeline;
