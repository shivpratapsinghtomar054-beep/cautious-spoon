
import React, { useState, useEffect } from 'react';
import { KeyboardSettings } from '../types';
import { audioService } from '../services/audioService';

interface KeyboardProps {
  settings: KeyboardSettings;
  onKeyPress: (char: string) => void;
  highlightedKeys: Set<string>;
}

const Keyboard: React.FC<KeyboardProps> = ({ settings, onKeyPress, highlightedKeys }) => {
  const [isShifted, setIsShifted] = useState(false);

  const rows = [
    ['Q', 'W', 'E', 'R', 'T', 'Y', 'U', 'I', 'O', 'P'],
    ['A', 'S', 'D', 'F', 'G', 'H', 'J', 'K', 'L'],
    ['SHIFT', 'Z', 'X', 'C', 'V', 'B', 'N', 'M', 'BACKSPACE'],
    ['123', 'SPACE', 'ENTER']
  ];

  const handleKeyClick = (key: string) => {
    if (key === 'SHIFT') {
      setIsShifted(!isShifted);
      return;
    }

    if (settings.soundEnabled && key.length === 1 && /[A-Z]/.test(key)) {
      audioService.playNote(key, settings.volume, settings.instrumentType);
    }

    if (key === 'BACKSPACE') {
      onKeyPress('BS');
    } else if (key === 'ENTER') {
      onKeyPress('ENT');
    } else if (key === 'SPACE') {
      onKeyPress(' ');
    } else if (key === '123') {
      return;
    } else {
      onKeyPress(isShifted ? key.toUpperCase() : key.toLowerCase());
    }
  };

  return (
    <div className="bg-[#1e293b] p-2 select-none w-full max-w-md mx-auto rounded-t-2xl shadow-2xl relative">
      {settings.musicMode.enabled && (
        <div className="absolute -top-1 left-0 right-0 h-1 bg-blue-500 animate-pulse rounded-full"></div>
      )}
      
      <div className="flex flex-col gap-2">
        {rows.map((row, rowIndex) => (
          <div key={rowIndex} className="flex justify-center gap-1.5">
            {row.map((key) => {
              let width = 'flex-1';
              if (key === 'SPACE') width = 'flex-[4]';
              if (key === 'SHIFT' || key === 'BACKSPACE') width = 'flex-[1.5]';
              if (key === 'ENTER' || key === '123') width = 'flex-[1.2]';

              const isHighlighted = highlightedKeys.has(key.toUpperCase());
              const highlightStyle = isHighlighted ? {
                backgroundColor: settings.musicMode.highlightColor,
                boxShadow: `0 0 15px ${settings.musicMode.highlightColor}`,
                transform: 'scale(1.05)',
                zIndex: 10
              } : {};

              return (
                <button
                  key={key}
                  onMouseDown={(e) => {
                    e.preventDefault();
                    handleKeyClick(key);
                  }}
                  style={highlightStyle}
                  className={`${width} h-12 md:h-14 rounded-lg bg-[#334155] text-white font-medium flex items-center justify-center 
                  active:bg-blue-400 active:scale-95 transition-all duration-150 shadow-sm text-sm sm:text-base`}
                >
                  {key === 'BACKSPACE' ? <i className="fa-solid fa-delete-left"></i> : 
                   key === 'SHIFT' ? <i className={`fa-solid fa-arrow-up ${isShifted ? 'text-blue-400' : ''}`}></i> :
                   key === 'ENTER' ? <i className="fa-solid fa-arrow-turn-down transform rotate-90"></i> :
                   key === 'SPACE' ? '' : 
                   isShifted ? key.toUpperCase() : key.toLowerCase()}
                </button>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
};

export default Keyboard;
