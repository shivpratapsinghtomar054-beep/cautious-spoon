
import React from 'react';

interface InstructionsProps {
  onBack: () => void;
}

const Instructions: React.FC<InstructionsProps> = ({ onBack }) => {
  const steps = [
    { title: "Enable Keyboard", desc: "Go to Settings > System > Languages & Input > On-screen keyboard." },
    { title: "Manage Keyboards", desc: "Tap 'Manage on-screen keyboards' and toggle on 'GuitarKey'." },
    { title: "Grant Permission", desc: "Select 'OK' on the Android system warning (standard for all custom keyboards)." },
    { title: "Switch Method", desc: "Open any app, tap a text field, and select the keyboard icon in the bottom corner to switch to GuitarKey." }
  ];

  return (
    <div className="p-6 h-full flex flex-col bg-slate-900 animate-in fade-in slide-in-from-right duration-300">
      <div className="flex items-center gap-4 mb-8">
        <button onClick={onBack} className="p-2 hover:bg-slate-800 rounded-full transition-colors">
          <i className="fa-solid fa-arrow-left text-xl"></i>
        </button>
        <h2 className="text-2xl font-bold">Setup Guide</h2>
      </div>

      <div className="space-y-6 flex-1 overflow-y-auto pb-8">
        {steps.map((step, i) => (
          <div key={i} className="flex gap-4 p-4 bg-slate-800/50 rounded-2xl border border-slate-700">
            <div className="flex-shrink-0 w-8 h-8 bg-blue-500 rounded-full flex items-center justify-center font-bold">
              {i + 1}
            </div>
            <div>
              <h4 className="font-bold text-lg mb-1">{step.title}</h4>
              <p className="text-slate-400 text-sm leading-relaxed">{step.desc}</p>
            </div>
          </div>
        ))}

        <div className="mt-4 p-4 bg-amber-500/10 border border-amber-500/20 rounded-xl text-amber-200 text-sm">
          <i className="fa-solid fa-circle-info mr-2"></i>
          This simulator demonstrates the audio and UI experience. To use this as a system-wide keyboard, follow the Kotlin/Java implementation steps.
        </div>
      </div>
    </div>
  );
};

export default Instructions;
